/*
 * Code for class EV_POINTER_STYLE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern EIF_TYPED_VALUE F970_8348(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8349(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8350(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8351(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8352(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8353(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8354(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8355(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8356(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8357(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8358(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8359(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8360(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8361(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8362(EIF_REFERENCE);
extern EIF_TYPED_VALUE F970_8363(EIF_REFERENCE, EIF_TYPED_VALUE);
extern void EIF_Minit970(void);

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POINTER_STYLE_CONSTANTS}.busy_cursor */
EIF_TYPED_VALUE F970_8348 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.standard_cursor */
EIF_TYPED_VALUE F970_8349 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.crosshair_cursor */
EIF_TYPED_VALUE F970_8350 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.help_cursor */
EIF_TYPED_VALUE F970_8351 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.ibeam_cursor */
EIF_TYPED_VALUE F970_8352 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.no_cursor */
EIF_TYPED_VALUE F970_8353 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.sizeall_cursor */
EIF_TYPED_VALUE F970_8354 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.sizens_cursor */
EIF_TYPED_VALUE F970_8355 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.sizenwse_cursor */
EIF_TYPED_VALUE F970_8356 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.sizenesw_cursor */
EIF_TYPED_VALUE F970_8357 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.sizewe_cursor */
EIF_TYPED_VALUE F970_8358 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.uparrow_cursor */
EIF_TYPED_VALUE F970_8359 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.wait_cursor */
EIF_TYPED_VALUE F970_8360 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.header_sizewe_cursor */
EIF_TYPED_VALUE F970_8361 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.hyperlink_cursor */
EIF_TYPED_VALUE F970_8362 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	return r;
}

/* {EV_POINTER_STYLE_CONSTANTS}.is_valid */
EIF_TYPED_VALUE F970_8363 (EIF_REFERENCE Current, EIF_TYPED_VALUE arg1x)
{
	GTCX
	char *l_feature_name = "is_valid";
	RTEX;
#define arg1 arg1x.it_i4
	EIF_TYPED_VALUE up1x = {{0}, SK_POINTER};
#define up1 up1x.it_p
	EIF_TYPED_VALUE ui4_1x = {{0}, SK_INT32};
#define ui4_1 ui4_1x.it_i4
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	if ((arg1x.type & SK_HEAD) == SK_REF) arg1x.it_i4 = * (EIF_INTEGER_32 *) arg1x.it_r;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	RTLU (SK_BOOL, &Result);
	RTLU(SK_INT32,&arg1);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 969, Current, 0, 1, 14663);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 0);
	RTGC;
	RTDBGEAA(969, Current, 14663);
	RTIV(Current, RTAL);
	RTHOOK(1);
	RTDBGAL(0, 0x04000000, 1,0); /* Result */
	ti4_1 = (((FUNCTION_CAST(EIF_TYPED_VALUE, (EIF_REFERENCE)) RTWF(6138, dtype))(Current)).it_i4);
	ti4_2 = (((FUNCTION_CAST(EIF_TYPED_VALUE, (EIF_REFERENCE)) RTWF(6152, dtype))(Current)).it_i4);
	ui4_1 = ti4_2;
	tr1 = RTLN(eif_new_type(221, 0x00).id);
	*(EIF_INTEGER_32 *)tr1 = ti4_1;
	tr2 = ((up1x = (FUNCTION_CAST(EIF_TYPED_VALUE, (EIF_REFERENCE, EIF_TYPED_VALUE)) RTVF(4487, "interval", tr1))(tr1, ui4_1x)), (((up1x.type & SK_HEAD) == SK_REF)? (EIF_REFERENCE) 0: (up1x.it_r = RTBU(up1x))), (up1x.type = SK_POINTER), up1x.it_r);
	ui4_1 = arg1;
	tb1 = (((FUNCTION_CAST(EIF_TYPED_VALUE, (EIF_REFERENCE, EIF_TYPED_VALUE)) RTVF(2677, "valid_index", tr2))(tr2, ui4_1x)).it_b);
	Result = (EIF_BOOLEAN) tb1;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(2);
	RTDBGLE;
	RTMD(0);
	RTLE;
	RTLO(3);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_BOOL; r.it_b = Result; return r; }
#undef up1
#undef ui4_1
#undef arg1
}

void EIF_Minit970 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
