/*
 * Code for class UC_UNICODE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern EIF_TYPED_VALUE F1026_8777(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8778(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8779(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8780(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8781(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8782(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8783(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8784(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8785(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8786(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8787(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8788(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8789(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8790(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8791(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8792(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8793(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8794(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8795(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8796(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8797(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8798(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8799(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8800(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8801(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8802(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8803(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8804(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8805(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8806(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8807(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8808(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8809(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8810(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8811(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8812(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8813(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8814(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8815(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8816(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8817(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8818(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8819(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8820(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8821(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8822(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8823(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8824(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8825(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8826(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8827(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8828(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8829(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8830(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8831(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1026_8832(EIF_REFERENCE);
extern void EIF_Minit1026(void);

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UNICODE_CONSTANTS}.minimum_unicode_character_code */
EIF_TYPED_VALUE F1026_8777 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.maximum_unicode_character_code */
EIF_TYPED_VALUE F1026_8778 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1114111L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.minimum_unicode_surrogate_code */
EIF_TYPED_VALUE F1026_8779 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 55296L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.maximum_unicode_surrogate_code */
EIF_TYPED_VALUE F1026_8780 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57343L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.maximum_bmp_character_code */
EIF_TYPED_VALUE F1026_8781 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65535L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.minimum_ascii_character_code */
EIF_TYPED_VALUE F1026_8782 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.maximum_ascii_character_code */
EIF_TYPED_VALUE F1026_8783 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.minimum_ascii_character */
EIF_TYPED_VALUE F1026_8784 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_CHAR8;
	r.it_c1 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	return r;
}

/* {UC_UNICODE_CONSTANTS}.maximum_ascii_character */
EIF_TYPED_VALUE F1026_8785 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_CHAR8;
	r.it_c1 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '';
	return r;
}

/* {UC_UNICODE_CONSTANTS}.unassigned_other_category */
EIF_TYPED_VALUE F1026_8786 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.uppercase_letter_category */
EIF_TYPED_VALUE F1026_8787 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.lowercase_letter_category */
EIF_TYPED_VALUE F1026_8788 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.titlecase_letter_category */
EIF_TYPED_VALUE F1026_8789 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.modifier_letter_category */
EIF_TYPED_VALUE F1026_8790 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.other_letter_category */
EIF_TYPED_VALUE F1026_8791 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.non_spacing_mark_category */
EIF_TYPED_VALUE F1026_8792 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.spacing_combining_mark_category */
EIF_TYPED_VALUE F1026_8793 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.enclosing_mark_category */
EIF_TYPED_VALUE F1026_8794 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.decimal_digit_number_category */
EIF_TYPED_VALUE F1026_8795 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.letter_number_category */
EIF_TYPED_VALUE F1026_8796 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.other_number_category */
EIF_TYPED_VALUE F1026_8797 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.connector_punctuation_category */
EIF_TYPED_VALUE F1026_8798 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.dash_punctuation_category */
EIF_TYPED_VALUE F1026_8799 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.open_punctuation_category */
EIF_TYPED_VALUE F1026_8800 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.close_punctuation_category */
EIF_TYPED_VALUE F1026_8801 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.initial_quote_punctuation_category */
EIF_TYPED_VALUE F1026_8802 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.final_quote_punctuation_category */
EIF_TYPED_VALUE F1026_8803 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.other_punctuation_category */
EIF_TYPED_VALUE F1026_8804 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.math_symbol_category */
EIF_TYPED_VALUE F1026_8805 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.currency_symbol_category */
EIF_TYPED_VALUE F1026_8806 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.modifier_symbol_category */
EIF_TYPED_VALUE F1026_8807 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 21L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.other_symbol_category */
EIF_TYPED_VALUE F1026_8808 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.space_separator_category */
EIF_TYPED_VALUE F1026_8809 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.line_separator_category */
EIF_TYPED_VALUE F1026_8810 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 24L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.paragraph_separator_category */
EIF_TYPED_VALUE F1026_8811 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.control_other_category */
EIF_TYPED_VALUE F1026_8812 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.format_other_category */
EIF_TYPED_VALUE F1026_8813 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.surrogate_other_category */
EIF_TYPED_VALUE F1026_8814 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.private_other_category */
EIF_TYPED_VALUE F1026_8815 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 29L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.canonical_decomposition_mapping */
EIF_TYPED_VALUE F1026_8816 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.font_decomposition_mapping */
EIF_TYPED_VALUE F1026_8817 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.no_break_decomposition_mapping */
EIF_TYPED_VALUE F1026_8818 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.initial_decomposition_mapping */
EIF_TYPED_VALUE F1026_8819 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.medial_decomposition_mapping */
EIF_TYPED_VALUE F1026_8820 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.final_decomposition_mapping */
EIF_TYPED_VALUE F1026_8821 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.isolated_decomposition_mapping */
EIF_TYPED_VALUE F1026_8822 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.encircled_decomposition_mapping */
EIF_TYPED_VALUE F1026_8823 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.superscript_decomposition_mapping */
EIF_TYPED_VALUE F1026_8824 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.subscript_decomposition_mapping */
EIF_TYPED_VALUE F1026_8825 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.vertical_decomposition_mapping */
EIF_TYPED_VALUE F1026_8826 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.wide_decomposition_mapping */
EIF_TYPED_VALUE F1026_8827 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.narrow_decomposition_mapping */
EIF_TYPED_VALUE F1026_8828 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.small_decomposition_mapping */
EIF_TYPED_VALUE F1026_8829 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.square_decomposition_mapping */
EIF_TYPED_VALUE F1026_8830 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.fraction_decomposition_mapping */
EIF_TYPED_VALUE F1026_8831 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	return r;
}

/* {UC_UNICODE_CONSTANTS}.compatibility_decomposition_mapping */
EIF_TYPED_VALUE F1026_8832 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	return r;
}

void EIF_Minit1026 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
