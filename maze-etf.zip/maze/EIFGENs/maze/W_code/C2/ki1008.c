/*
 * Code for class KI_PLATFORM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern EIF_TYPED_VALUE F1008_8677(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1008_8684(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1008_8690(EIF_REFERENCE);
extern EIF_TYPED_VALUE F1008_8691(EIF_REFERENCE);
extern void EIF_Minit1008(void);

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KI_PLATFORM}.byte_bits */
EIF_TYPED_VALUE F1008_8677 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	return r;
}

/* {KI_PLATFORM}.byte_bytes */
EIF_TYPED_VALUE F1008_8684 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	return r;
}

/* {KI_PLATFORM}.minimum_byte_code */
EIF_TYPED_VALUE F1008_8690 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	return r;
}

/* {KI_PLATFORM}.maximum_byte_code */
EIF_TYPED_VALUE F1008_8691 (EIF_REFERENCE Current)
{
	EIF_TYPED_VALUE r;
	r.type = SK_INT32;
	r.it_i4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	return r;
}

void EIF_Minit1008 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
